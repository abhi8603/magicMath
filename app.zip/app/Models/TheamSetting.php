<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TheamSetting extends Model
{
     protected $table='theam_setting';
}
