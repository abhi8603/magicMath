<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class CreateSchool extends Model
{
     protected $table='create_school';
}
