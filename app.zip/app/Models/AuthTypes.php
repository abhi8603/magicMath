<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AuthTypes extends Model
{
     protected $table='auth_types';
}
